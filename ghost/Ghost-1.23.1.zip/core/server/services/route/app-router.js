var ParentRouter = require('./ParentRouter'),
    appRouter = new ParentRouter('apps');

module.exports = appRouter;
